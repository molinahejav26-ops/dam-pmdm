import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResourceList, NamedApiResource, Pokemon } from '../interfaces/pokemon-interace';

@Injectable({
  providedIn: 'root'
})
export class PokemonService {
  private apiUrl = 'https://pokeapi.co/api/v2/pokemon';

  constructor(private http: HttpClient) {}

  getPokemonList(limit: number = 20, offset: number = 0): Observable<ApiResourceList<NamedApiResource>> {
    return this.http.get<ApiResourceList<NamedApiResource>>(`${this.apiUrl}?limit=${limit}&offset=${offset}`);
  }

  getPokemonDetail(nameOrId: string | number): Observable<Pokemon> {
    return this.http.get<Pokemon>(`${this.apiUrl}/${nameOrId}`);
  }
}