import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResourceList, Berry, NamedApiResource } from '../interfaces/pokemon-interace';

@Injectable({
  providedIn: 'root'
})
export class BerryService {
  private apiUrl = 'https://pokeapi.co/api/v2/berry';

  constructor(private http: HttpClient) {}

  getBerryList(limit: number = 20, offset: number = 0): Observable<ApiResourceList<NamedApiResource>> {
    return this.http.get<ApiResourceList<NamedApiResource>>(`${this.apiUrl}?limit=${limit}&offset=${offset}`);
  }

  getBerryDetail(nameOrId: string | number): Observable<Berry> {
    return this.http.get<Berry>(`${this.apiUrl}/${nameOrId}`);
  }
}
