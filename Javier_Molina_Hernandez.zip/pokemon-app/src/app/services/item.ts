import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResourceList, Item, NamedApiResource } from '../interfaces/pokemon-interace';

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  private apiUrl = 'https://pokeapi.co/api/v2/item';

  constructor(private http: HttpClient) {}

  getItemList(limit: number = 20, offset: number = 0): Observable<ApiResourceList<NamedApiResource>> {
    return this.http.get<ApiResourceList<NamedApiResource>>(`${this.apiUrl}?limit=${limit}&offset=${offset}`);
  }

  getItemDetail(nameOrId: string | number): Observable<Item> {
    return this.http.get<Item>(`${this.apiUrl}/${nameOrId}`);
  }
}
