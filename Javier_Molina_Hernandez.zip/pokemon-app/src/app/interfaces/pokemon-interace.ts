export interface NamedApiResource {
  name: string;
  url: string;
}

export interface ApiResourceList<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

export interface Pokemon {
  id: number;
  name: string;
  height: number;
  weight: number;
  sprites: {
    front_default: string | null;
  };
  types: Array<{
    slot: number;
    type: NamedApiResource;
  }>;
}

export interface Berry {
  id: number;
  name: string;
  growth_time: number;
  size: number;
  natural_gift_power: number;
}

export interface Item {
  id: number;
  name: string;
  prices: Array<{
    purchase_price: number | null;
    sell_price: number | null;
    currency: NamedApiResource;
    version_group: NamedApiResource;
  }>;
  sprites: {
    default: string | null;
  };
  category: NamedApiResource;
}
