import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NamedApiResource } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-berry-item',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './berry-item.html',
  styleUrl: './berry-item.css'
})
export class BerryItemComponent implements OnInit {
  @Input() berryData!: NamedApiResource;
  berryId!: number;
  imageUrl!: string;

  ngOnInit(): void {
    const parts = this.berryData.url.split('/').filter(Boolean);
    this.berryId = +parts[parts.length - 1];
    this.imageUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/berries/${this.berryData.name}-berry.png`;
  }
}
