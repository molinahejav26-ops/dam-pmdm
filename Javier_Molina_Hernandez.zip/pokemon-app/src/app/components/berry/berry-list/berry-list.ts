import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BerryService } from '../../../services/berry';
import { BerryItemComponent } from '../berry-item/berry-item';
import { NamedApiResource } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-berry-list',
  standalone: true,
  imports: [CommonModule, BerryItemComponent],
  templateUrl: './berry-list.html',
  styleUrl: './berry-list.css'
})
export class BerryListComponent implements OnInit {
  berryList = signal<NamedApiResource[]>([]);
  isLoading = signal(true);
  errorMessage = signal<string | null>(null);

  constructor(private berryService: BerryService) {}

  ngOnInit(): void {
    this.berryService.getBerryList(20, 0).subscribe(data => {
      this.berryList.set(data.results);
      this.isLoading.set(false);
    }, () => {
      this.errorMessage.set('No se pudo cargar la lista de bayas.');
      this.isLoading.set(false);
    });
  }
}
