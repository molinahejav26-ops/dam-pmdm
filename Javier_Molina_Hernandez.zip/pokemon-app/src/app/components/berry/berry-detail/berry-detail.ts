import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { BerryService } from '../../../services/berry';
import { Berry } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-berry-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './berry-detail.html',
  styleUrl: './berry-detail.css'
})
export class BerryDetailComponent implements OnInit {
  berryDetail = signal<Berry | null>(null);
  isLoading = signal(true);
  errorMessage = signal<string | null>(null);
  imageUrl = signal('');

  constructor(
    private route: ActivatedRoute,
    private berryService: BerryService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.berryService.getBerryDetail(id).subscribe(data => {
        this.berryDetail.set(data);
        this.imageUrl.set(`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/berries/${data.name}-berry.png`);
        this.isLoading.set(false);
      }, () => {
        this.errorMessage.set('No se pudo cargar la información de la baya.');
        this.isLoading.set(false);
      });
    } else {
      this.errorMessage.set('No se encontró el identificador de la baya.');
      this.isLoading.set(false);
    }
  }
}
