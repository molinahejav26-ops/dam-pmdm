import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PokemonService } from '../../../services/pokemon';
import { PokemonItemComponent } from '../pokemon-item/pokemon-item';
import { NamedApiResource } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-pokemon-list',
  standalone: true,
  imports: [CommonModule, PokemonItemComponent],
  templateUrl: './pokemon-list.html',
  styleUrl: './pokemon-list.css'
})
export class PokemonListComponent implements OnInit {
  pokemonList = signal<NamedApiResource[]>([]);
  isLoading = signal(true);
  errorMessage = signal<string | null>(null);

  constructor(private pokemonService: PokemonService) {}

  ngOnInit(): void {
    this.pokemonService.getPokemonList(20, 0).subscribe(data => {
      this.pokemonList.set(data.results);
      this.isLoading.set(false);
    }, () => {
      this.errorMessage.set('No se pudo cargar la lista de Pokémon.');
      this.isLoading.set(false);
    });
  }
}
