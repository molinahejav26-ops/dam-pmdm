import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { PokemonService } from '../../../services/pokemon';
import { Pokemon } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-pokemon-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './pokemon-detail.html',
  styleUrl: './pokemon-detail.css'
})
export class PokemonDetailComponent implements OnInit {
  pokemonDetail = signal<Pokemon | null>(null);
  isLoading = signal(true);
  errorMessage = signal<string | null>(null);

  constructor(
    private route: ActivatedRoute,
    private pokemonService: PokemonService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.pokemonService.getPokemonDetail(id).subscribe(data => {
        this.pokemonDetail.set(data);
        this.isLoading.set(false);
      }, () => {
        this.errorMessage.set('No se pudo cargar la información del Pokémon.');
        this.isLoading.set(false);
      });
    } else {
      this.errorMessage.set('No se encontró el identificador del Pokémon.');
      this.isLoading.set(false);
    }
  }
}
