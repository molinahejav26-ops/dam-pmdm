import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NamedApiResource } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-pokemon-item',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './pokemon-item.html',
  styleUrl: './pokemon-item.css'
})
export class PokemonItemComponent implements OnInit {
  @Input() pokemonData!: NamedApiResource;
  pokemonId!: number;
  imageUrl!: string;

  ngOnInit(): void {
    const parts = this.pokemonData.url.split('/').filter(Boolean);
    this.pokemonId = +parts[parts.length - 1];
    this.imageUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${this.pokemonId}.png`;
  }
}
