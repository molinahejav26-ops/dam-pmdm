import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ItemService } from '../../../services/item';
import { Item } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-item-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './item-detail.html',
  styleUrl: './item-detail.css'
})
export class ItemDetailComponent implements OnInit {
  itemDetail = signal<Item | null>(null);
  isLoading = signal(true);
  errorMessage = signal<string | null>(null);

  get purchasePrice(): number | null {
    return this.itemDetail()?.prices.find(price => price.purchase_price !== null)?.purchase_price ?? null;
  }

  constructor(
    private route: ActivatedRoute,
    private itemService: ItemService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.itemService.getItemDetail(id).subscribe(data => {
        this.itemDetail.set(data);
        this.isLoading.set(false);
      }, () => {
        this.errorMessage.set('No se pudo cargar la información del objeto.');
        this.isLoading.set(false);
      });
    } else {
      this.errorMessage.set('No se encontró el identificador del objeto.');
      this.isLoading.set(false);
    }
  }
}