import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NamedApiResource } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-item-item',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './item-item.html',
  styleUrl: './item-item.css'
})
export class ItemItemComponent implements OnInit {
  @Input() itemData!: NamedApiResource;
  itemId!: number;
  imageUrl!: string;

  ngOnInit(): void {
    const parts = this.itemData.url.split('/').filter(Boolean);
    this.itemId = +parts[parts.length - 1];
    this.imageUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/${this.itemData.name}.png`;
  }
}
