import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ItemService } from '../../../services/item';
import { ItemItemComponent } from '../item-item/item-item';
import { NamedApiResource } from '../../../interfaces/pokemon-interace';

@Component({
  selector: 'app-item-list',
  standalone: true,
  imports: [CommonModule, ItemItemComponent],
  templateUrl: './item-list.html',
  styleUrl: './item-list.css'
})
export class ItemListComponent implements OnInit {
  itemList = signal<NamedApiResource[]>([]);
  isLoading = signal(true);
  errorMessage = signal<string | null>(null);

  constructor(private itemService: ItemService) {}

  ngOnInit(): void {
    this.itemService.getItemList(20, 0).subscribe(data => {
      this.itemList.set(data.results);
      this.isLoading.set(false);
    }, () => {
      this.errorMessage.set('No se pudo cargar la lista de objetos.');
      this.isLoading.set(false);
    });
  }
}