import { $n as Output, Ca as ɵɵclassProp, Cc as EventEmitter, En as ElementRef, In as Input, Rc as NgZone, Wi as setClassMetadata, ao as ɵɵdefineNgModule, dl as inject, dr as Service, io as ɵɵdefineDirective, jl as ɵɵdefineInjector, qn as NgModule, so as ɵɵdefineService, wn as Directive } from "./core-DwcU5Din.js";
import { _ as ngbCollapsingTransition, x as ngbRunTransition } from "./_ngb-ngbootstrap-utilities-BKJLBmtL.js";
import { t as NgbConfig } from "./ng-bootstrap-ng-bootstrap-config-D7zCfNOX.js";
//#region node_modules/@ng-bootstrap/ng-bootstrap/fesm2022/ng-bootstrap-ng-bootstrap-collapse.mjs
/**
* A configuration service for the [NgbCollapse](#/components/collapse/api#NgbCollapse) component.
*
* You can inject this service, typically in your root component, and customize its properties
* to provide default values for all collapses used in the application.
*/
var NgbCollapseConfig = class NgbCollapseConfig {
	constructor() {
		this._ngbConfig = inject(NgbConfig);
		this.horizontal = false;
	}
	/**
	* @defaultValue `true`
	*/
	get animation() {
		return this._animation ?? this._ngbConfig.animation;
	}
	set animation(animation) {
		this._animation = animation;
	}
	static {
		this.ɵfac = function NgbCollapseConfig_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || NgbCollapseConfig)();
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineService({
			token: NgbCollapseConfig,
			factory: NgbCollapseConfig.ɵfac
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgbCollapseConfig, [{ type: Service }], null, null);
})();
/**
* A directive to provide a simple way of hiding and showing elements on the
* page.
*/
var NgbCollapse = class NgbCollapse {
	constructor() {
		this._config = inject(NgbCollapseConfig);
		this._element = inject(ElementRef);
		this._zone = inject(NgZone);
		/**
		* If `true`, collapse will be animated.
		*
		* Animation is triggered only when clicked on triggering element
		* or via the `.toggle()` function
		*
		* @since 8.0.0
		*/
		this.animation = this._config.animation;
		/**
		* Flag used to track if the collapse setter is invoked during initialization
		* or not. This distinction is made in order to avoid running the transition during initialization.
		*/
		this._afterInit = false;
		this._isCollapsed = false;
		this.ngbCollapseChange = new EventEmitter();
		/**
		* If `true`, will collapse horizontally.
		*
		* @since 13.1.0
		*/
		this.horizontal = this._config.horizontal;
		/**
		* An event emitted when the collapse element is shown, after the transition.
		* It has no payload.
		*
		* @since 8.0.0
		*/
		this.shown = new EventEmitter();
		/**
		* An event emitted when the collapse element is hidden, after the transition.
		* It has no payload.
		*
		* @since 8.0.0
		*/
		this.hidden = new EventEmitter();
	}
	/**
	* If `true`, will collapse the element or show it otherwise.
	*/
	set collapsed(isCollapsed) {
		if (this._isCollapsed !== isCollapsed) {
			this._isCollapsed = isCollapsed;
			if (this._afterInit) this._runTransitionWithEvents(isCollapsed, this.animation);
		}
	}
	ngOnInit() {
		this._runTransition(this._isCollapsed, false);
		this._afterInit = true;
	}
	/**
	* Triggers collapsing programmatically.
	*
	* If there is a collapsing transition running already, it will be reversed.
	* If the animations are turned off this happens synchronously.
	*
	* @since 8.0.0
	*/
	toggle(open = this._isCollapsed) {
		this.collapsed = !open;
		this.ngbCollapseChange.next(this._isCollapsed);
	}
	_runTransition(collapsed, animation) {
		return ngbRunTransition(this._zone, this._element.nativeElement, ngbCollapsingTransition, {
			animation,
			runningTransition: "stop",
			context: {
				direction: collapsed ? "hide" : "show",
				dimension: this.horizontal ? "width" : "height"
			}
		});
	}
	_runTransitionWithEvents(collapsed, animation) {
		this._runTransition(collapsed, animation).subscribe(() => {
			if (collapsed) this.hidden.emit();
			else this.shown.emit();
		});
	}
	static {
		this.ɵfac = function NgbCollapse_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || NgbCollapse)();
		};
	}
	static {
		this.ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
			type: NgbCollapse,
			selectors: [[
				"",
				"ngbCollapse",
				""
			]],
			hostVars: 2,
			hostBindings: function NgbCollapse_HostBindings(rf, ctx) {
				if (rf & 2) ɵɵclassProp("collapse-horizontal", ctx.horizontal);
			},
			inputs: {
				animation: "animation",
				collapsed: [
					0,
					"ngbCollapse",
					"collapsed"
				],
				horizontal: "horizontal"
			},
			outputs: {
				ngbCollapseChange: "ngbCollapseChange",
				shown: "shown",
				hidden: "hidden"
			},
			exportAs: ["ngbCollapse"]
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgbCollapse, [{
		type: Directive,
		args: [{
			selector: "[ngbCollapse]",
			exportAs: "ngbCollapse",
			host: { "[class.collapse-horizontal]": "horizontal" }
		}]
	}], null, {
		animation: [{ type: Input }],
		collapsed: [{
			type: Input,
			args: ["ngbCollapse"]
		}],
		ngbCollapseChange: [{ type: Output }],
		horizontal: [{ type: Input }],
		shown: [{ type: Output }],
		hidden: [{ type: Output }]
	});
})();
var NgbCollapseModule = class NgbCollapseModule {
	static {
		this.ɵfac = function NgbCollapseModule_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || NgbCollapseModule)();
		};
	}
	static {
		this.ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
			type: NgbCollapseModule,
			imports: [NgbCollapse],
			exports: [NgbCollapse]
		});
	}
	static {
		this.ɵinj = /*@__PURE__*/ ɵɵdefineInjector({});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgbCollapseModule, [{
		type: NgModule,
		args: [{
			imports: [NgbCollapse],
			exports: [NgbCollapse]
		}]
	}], null, null);
})();
//#endregion
export { NgbCollapse, NgbCollapseConfig, NgbCollapseModule };
