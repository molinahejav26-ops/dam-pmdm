import { Gl as operate } from "./core-DwcU5Din.js";
import { i as concat } from "./tap-22W51X7w.js";
import { u as popScheduler } from "./filter-BwwWfsb4.js";
//#region node_modules/rxjs/dist/esm5/internal/operators/startWith.js
function startWith() {
	var values = [];
	for (var _i = 0; _i < arguments.length; _i++) values[_i] = arguments[_i];
	var scheduler = popScheduler(values);
	return operate(function(source, subscriber) {
		(scheduler ? concat(values, source, scheduler) : concat(values, source)).subscribe(subscriber);
	});
}
//#endregion
export { startWith as t };
