import { Hl as require_cjs, fc as require_operators, fl as inject, tl as assertInInjectionContext, yc as DestroyRef } from "./core-DgGCcKtC.js";
//#region node_modules/@angular/core/fesm2022/rxjs-interop.mjs
var import_cjs = require_cjs();
var import_operators = require_operators();
/**
* @license Angular v22.2.3
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
function takeUntilDestroyed(destroyRef) {
	if (!destroyRef) {
		ngDevMode && assertInInjectionContext(takeUntilDestroyed);
		destroyRef = inject(DestroyRef);
	}
	const destroyed$ = new import_cjs.Observable((subscriber) => {
		if (destroyRef.destroyed) {
			subscriber.next();
			return;
		}
		return destroyRef.onDestroy(subscriber.next.bind(subscriber));
	});
	return (source) => {
		return source.pipe((0, import_operators.takeUntil)(destroyed$));
	};
}
//#endregion
export { takeUntilDestroyed as t };
