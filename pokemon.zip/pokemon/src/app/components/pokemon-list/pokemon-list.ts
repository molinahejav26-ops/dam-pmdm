import { Component } from '@angular/core';
import { Pokemon } from '../../interfaces/pokemon.interface';
import { PokemonItemComponent } from '../pokemon-item/pokemon-item';

@Component({
  selector: 'app-pokemon-list',
  standalone: true,
  imports: [PokemonItemComponent],
  templateUrl: './pokemon-list.html',
  styleUrl: './pokemon-list.css'
})
export class PokemonListComponent {
  pokemonList: Pokemon[] = [
    { id: 1, name: 'Bulbasaur', type: 'Planta / Veneno', imageUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png' },
    { id: 4, name: 'Charmander', type: 'Fuego', imageUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png' },
    { id: 7, name: 'Squirtle', type: 'Agua', imageUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/7.png' },
    { id: 25, name: 'Pikachu', type: 'Eléctrico', imageUrl: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png' }
  ];
}
