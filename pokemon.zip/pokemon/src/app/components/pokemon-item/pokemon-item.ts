import { Component, Input } from '@angular/core';
import { Pokemon } from '../../interfaces/pokemon.interface';

@Component({
  selector: 'app-pokemon-item',
  standalone: true,
  imports: [],
  templateUrl: './pokemon-item.html',
  styleUrl: './pokemon-item.css'
})
export class PokemonItemComponent {
  @Input() pokemon!: Pokemon;
}
